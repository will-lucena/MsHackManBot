﻿namespace RiddleBot
{
    public enum MoveType
    {
        UP,
        DOWN,
        LEFT,
        RIGHT,
        PASS
    }
}
