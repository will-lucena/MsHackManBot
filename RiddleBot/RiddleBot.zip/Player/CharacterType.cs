﻿namespace RiddleBot
{
    public enum CharacterType
    {
        BIXIE,
        BIXIETTE
    }
}